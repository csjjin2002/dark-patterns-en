# 🔬 Dark Pattern Labeling Test (English Version)

**Study 4: Within-subjects design — 5 sequences with mixed label levels per task**

Sangmyung University Graduate School of Business (MIS)  
Researcher: Cho Sungjin | Advisor: Prof. Yoo Jinho

---

## 🔗 Links

- **Participant Experiment:** https://csjjin2002.github.io/dark-patterns-en/
- **Researcher Dashboard:** https://csjjin2002.github.io/dark-patterns-en/researcher.html

---

## 📖 About

This is the **English version** of the dark pattern labeling usability experiment.  
Original Korean version: https://github.com/csjjin2002/dark-patterns

This experiment evaluates how different dark pattern warning label types (No Label, Passive Label, Interactive Label) affect user perception, decision-making, and manipulation awareness in mobile e-commerce interfaces.

---

## 🧪 Experiment Design

### Dark Pattern Types (5 Tasks)
| Code | Type | Description |
|------|------|-------------|
| FA | Forced Action | Bundled consent and no genuine opt-out |
| OB | Obstruction | Cancellation barriers and friction |
| SN | Sneaking | Drip pricing and hidden charges |
| II | Interface Interference | Pre-checked optional consents |
| SE | Social Engineering | Fake urgency and curated reviews |

### Label Levels
| Level | Name | Description |
|-------|------|-------------|
| L0 | No Label | No warning displayed |
| L1 | Passive Label | Amber banner with dark pattern type name |
| L2 | Interactive Label | Red banner with risk score + expandable detail popup |

### Latin Square Sequences (5 sequences × 20 participants each = 100 total)
| Seq | Task 1 | Task 2 | Task 3 | Task 4 | Task 5 |
|-----|--------|--------|--------|--------|--------|
| S1 | FA-L0 | OB-L1 | SN-L1 | II-L2 | SE-L2 |
| S2 | OB-L0 | SN-L1 | II-L1 | SE-L2 | FA-L2 |
| S3 | SN-L0 | II-L1 | SE-L1 | FA-L2 | OB-L2 |
| S4 | II-L0 | SE-L1 | FA-L1 | OB-L2 | SN-L2 |
| S5 | SE-L0 | FA-L1 | OB-L1 | SN-L2 | II-L2 |

---

## 📊 Data Collected

Per task:
- `participantId` — anonymous participant ID
- `sequenceId` — sequence assignment (1–5)
- `taskOrder` — task position (1–5)
- `taskType` — dark pattern type (FA/OB/SN/II/SE)
- `labelLevel` — label condition (L0/L1/L2)
- `taskCompletionTimeSec` — time on screen (seconds)
- `clickCount` — total clicks
- `errorClickCount` — clicks on CTA (compliance indicator)
- `goalSuccess` — 1 if user resisted dark pattern, 0 if complied
- `labelClick` — 1 if user opened label detail popup
- `decision` — user's final action string
- `manipulationAwareness` — 7-point Likert ("I felt manipulated")

Post-survey (3 items, 7-point Likert):
- `fairness` — "I felt this interface was fair."
- `transparency` — "I felt this interface provided information transparently."
- `trust` — "I felt I could trust this service."

Demographics:
- `age`, `gender`, `occupation`, `education`, `commerceYears`, `commerceFreq`

---

## 🗂 Repository Structure

```
dark-patterns-en/
├── index.html          # Main experiment (participant-facing)
├── researcher.html     # Researcher dashboard + data export
├── tracking/           # (Reserved for tracking data)
└── .github/
    └── workflows/
        └── pages.yml   # GitHub Pages auto-deploy
```

---

## 📡 Backend

Data is stored via Google Apps Script to Google Sheets.  
Fallback: localStorage (`dp_results2`)

---

*© 2025 Sangmyung University MIS Lab. For research use only.*
